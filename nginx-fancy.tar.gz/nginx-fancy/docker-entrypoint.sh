#!/bin/bash

# 确保模块配置被加载
if [ ! -f /etc/nginx/nginx.conf.default ]; then
    cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.default
    sed -i '1i load_module /etc/nginx/modules/ngx_http_fancyindex_module.so;' /etc/nginx/nginx.conf
fi

# 初始化索引
/usr/local/bin/create-index.sh

# 启动文件监控
/usr/local/bin/watch-files.sh &

# 启动 nginx
exec nginx -g 'daemon off;'
