#!/bin/bash

BASE_DIR="/usr/share/nginx/html"

while true; do
    inotifywait -r -e modify,create,delete,move "$BASE_DIR" 2>/dev/null
    echo "检测到文件变化，更新索引..."
    /usr/local/bin/create-index.sh
done
