#!/bin/bash

BASE_DIR="/usr/share/nginx/html"
INDEX_FILE="$BASE_DIR/.search-index.json"

echo "[" > "$INDEX_FILE"
first=true

find "$BASE_DIR" -type f \
    ! -name ".*" \
    ! -name "*.sh" \
    ! -path "*/\.*" \
    ! -path "*/theme/*" \
    -printf '%P\n' | while read -r file; do
    if [ "$first" = true ]; then
        first=false
    else
        echo "," >> "$INDEX_FILE"
    fi
    echo "\"$file\"" >> "$INDEX_FILE"
done

echo "]" >> "$INDEX_FILE"

chown nginx:nginx "$INDEX_FILE"
chmod 644 "$INDEX_FILE"
